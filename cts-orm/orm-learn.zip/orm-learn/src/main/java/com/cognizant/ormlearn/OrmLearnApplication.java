package com.cognizant.ormlearn;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.exception.CountryNotFoundException;
import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;

import java.util.List;

@SpringBootApplication
public class OrmLearnApplication {
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	private static CountryService service;

	private static void testGetAllCountries() {
		LOGGER.info("start testGetAllCountries()");

		List<Country> list = service.getAllCountries();
		LOGGER.debug("countries={}", list);

		LOGGER.info("end testGetAllCountries()");
	}

	private static void testGetCountryById() {
		LOGGER.info("start testGetCountryById()");

		String country = "Congo";
		String id = "CG";
		Country result = null;

		try {
			result = service.findCountryById(id);
		} catch (CountryNotFoundException e) {
			LOGGER.error(e.getMessage());
		}

		if (result != null && result.getName().equals(country)) {
			LOGGER.info("successful");
		} else {
			LOGGER.info("failed");
		}

		LOGGER.info("end testGetCountryById()");
	}

	private static void testAddCountry() {
		LOGGER.info("start testAddCountry()");

		Country newCountry = new Country();
		newCountry.setCode("IN");
		newCountry.setName("India");

		service.addCountry(newCountry);

		Country result = null;

		try {
			result = service.findCountryById("IN");
		} catch (CountryNotFoundException e) {
			LOGGER.error(e.getMessage());
		}

		if (result != null && result.getName().equals("India")) {
			LOGGER.info("success");
		} else {
			LOGGER.info("failed");
		}

		LOGGER.info("end testAddCountry()");
	}

	private static void testUpdateCountry() {
		LOGGER.info("start testUpdateCountry()");

		String code = "IN";
		String name = "Ind";

		service.updateCountry(code, name);

		Country result = null;

		try {
			result = service.findCountryById("IN");
		} catch (CountryNotFoundException e) {
			LOGGER.error(e.getMessage());
		}

		if (result != null && result.getName().equals("Ind")) {
			LOGGER.info("success");
		} else {
			LOGGER.info("failed");
		}

		LOGGER.info("end testUpdateCountry()");
	}
	
	
	private static void testDeleteCountry() {
		LOGGER.info("start deleteCountry()");
		
		String id="IN";
		
		service.deleteCountry(id);
		Country result = null;
		try {
			result = service.findCountryById("IN");
		} catch (CountryNotFoundException e) {
			LOGGER.error(e.getMessage());
		}
		
		if (result == null ) {
			LOGGER.info("success");
		} else {
			LOGGER.info("failed");
		}
		
		LOGGER.info("end deleteCountry()");
	}

	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);

		LOGGER.info("inside main");

		service = (CountryService) context.getBean("countryService");
		
		testGetAllCountries();
		testGetCountryById();
		testAddCountry();
		testUpdateCountry();
		testDeleteCountry();
		
		LOGGER.info("end");

	}

}
