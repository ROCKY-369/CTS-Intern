insert into country (co_code, co_name) values ("AF", "Afghanistan");

insert into country (co_code, co_name) values ("AL", "Albania");

insert into country (co_code, co_name) values ("DZ", "Algeria");

insert into country (co_code, co_name) values ("AS", "American Samoa");

insert into country (co_code, co_name) values ("AD", "Andorra");

insert into country (co_code, co_name) values ("AO", "Angola");

insert into country (co_code, co_name) values ("AI", "Anguilla");

insert into country (co_code, co_name) values ("AQ", "Antarctica");

insert into country (co_code, co_name) values ("AG", "Antigua and Barbuda");

insert into country (co_code, co_name) values ("AR", "Argentina");

insert into country (co_code, co_name) values ("AM", "Armenia");

insert into country (co_code, co_name) values ("AW", "Aruba");

insert into country (co_code, co_name) values ("AU", "Australia");

insert into country (co_code, co_name) values ("AT", "Austria");

insert into country (co_code, co_name) values ("AZ", "Azerbaijan");

insert into country (co_code, co_name) values ("BS", "Bahamas");

insert into country (co_code, co_name) values ("BH", "Bahrain");

insert into country (co_code, co_name) values ("BD", "Bangladesh");

insert into country (co_code, co_name) values ("BB", "Barbados");

insert into country (co_code, co_name) values ("BY", "Belarus");

insert into country (co_code, co_name) values ("BE", "Belgium");

insert into country (co_code, co_name) values ("BZ", "Belize");

insert into country (co_code, co_name) values ("BJ", "Benin");

insert into country (co_code, co_name) values ("BM", "Bermuda");

insert into country (co_code, co_name) values ("BT", "Bhutan");

insert into country (co_code, co_name) values ("BO", "Bolivia, Plurinational State of");

insert into country (co_code, co_name) values ("BQ", "Bonaire, Sint Eustatius and Saba");

insert into country (co_code, co_name) values ("BA", "Bosnia and Herzegovina");

insert into country (co_code, co_name) values ("BW", "Botswana");

insert into country (co_code, co_name) values ("BV", "Bouvet Island");

insert into country (co_code, co_name) values ("BR", "Brazil");

insert into country (co_code, co_name) values ("IO", "British Indian Ocean Territory");

insert into country (co_code, co_name) values ("BN", "Brunei Darussalam");

insert into country (co_code, co_name) values ("BG", "Bulgaria");

insert into country (co_code, co_name) values ("BF", "Burkina Faso");

insert into country (co_code, co_name) values ("BI", "Burundi");

insert into country (co_code, co_name) values ("KH", "Cambodia");

insert into country (co_code, co_name) values ("CM", "Cameroon");

insert into country (co_code, co_name) values ("CA", "Canada");

insert into country (co_code, co_name) values ("CV", "Cape Verde");

insert into country (co_code, co_name) values ("KY", "Cayman Islands");

insert into country (co_code, co_name) values ("CF", "Central African Republic");

insert into country (co_code, co_name) values ("TD", "Chad");

insert into country (co_code, co_name) values ("CL", "Chile");

insert into country (co_code, co_name) values ("CN", "China");

insert into country (co_code, co_name) values ("CX", "Christmas Island");

insert into country (co_code, co_name) values ("CC", "Cocos (Keeling) Islands");

insert into country (co_code, co_name) values ("CO", "Colombia");

insert into country (co_code, co_name) values ("KM", "Comoros");

insert into country (co_code, co_name) values ("CG", "Congo");

insert into country (co_code, co_name) values ("CD", "Congo, the Democratic Republic of the");

insert into country (co_code, co_name) values ("CK", "Cook Islands");

insert into country (co_code, co_name) values ("CR", "Costa Rica");

insert into country (co_code, co_name) values ("HR", "Croatia");

insert into country (co_code, co_name) values ("CU", "Cuba");

insert into country (co_code, co_name) values ("CW", "Curaçao");

insert into country (co_code, co_name) values ("CY", "Cyprus");