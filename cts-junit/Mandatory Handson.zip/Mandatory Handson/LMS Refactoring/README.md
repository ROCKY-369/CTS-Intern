# Hands On - LMS Refactoring

The  AVR College of Engineering has a library . The College wants to ease the functionalities of Library Management System(LMS).  In LMS, the Book details, Member details and Transaction details  are maintained.

Given the Member, MemberDAO, Book, BookDAO, Transaction and TransactionDAO classes.

Refactor the given classes by applying the PMD rule set. 

Refactor the given code in LMS class by checking the variable usage, variable naming conventions, method naming conventions, method parameters, Code size ,Constructor call,import statements, control structures,unused code, String instantiation and access specifiers.