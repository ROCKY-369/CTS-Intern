package com.cts.bank.exception;

public class AccountTransactionException extends Throwable {
    public AccountTransactionException(String message) {
        super(message);
    }
}
