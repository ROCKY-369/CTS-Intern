# Electricity Bill

Sam seems to be a busy man with very little time to spare for personal work like paying his electricity bill. The due date for payment of the electricity bill is nearing and as he is busy, decides to pay it online this time.  

Sam calculates the bill according to the Unit Slab rates listed in the following table:

| Unit Slabs | Tariff Rates | 
| ---------- | ------------ |
| First 50 Units | 2.60 | 
| Next100 Units | 3.25 |
| Next 200 Units | 5.26 |
| Next 1000 Units | 7.75 |

Write JUNIT test class named “EBBillTest” to test the method calculateBillAmount() in the given EBBill class.

You need to write only JUNIT code.