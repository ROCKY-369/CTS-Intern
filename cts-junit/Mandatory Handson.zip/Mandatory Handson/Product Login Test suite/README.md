# Product Login Test suite

Varunika is a software tester in an organization. She tests multiple test cases. She wants to make testing very simple so she decides to create a test suite which can run multiple test cases under a single unit.

Write JUNIT test class named LoginTest to test the `methoddeleteLogin()` in the given LoginDAO class.

Write JUNIT test class named ProductTest to test the method `deleteproduct()` in the given ProductDAO class.

Write a JUNIT Test Suite named `TestSuiteRunner` to run the test cases in both `LoginTest` and `ProductTest` classes.